(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customMyDatePickerV3', function() {
    return {
      controllerAs: 'ctrl',
      controller: function ($scope) {
    $scope.today = function() {
        $scope.properties.bt = new Date();
        //$scope.properties.value = $scope.dt;
    };
    $scope.today();
    var silvestre = new Date(2016, 1, 1);
    $scope.clear = function() {
        $scope.dt = null;
    };

    $scope.inlineOptions = {
        minDate: new Date(),
        showWeeks: false
    };
    $scope.dateOptions = {
        dateDisabled: disabled,
        formatYear: 'yy',
        maxDate: new Date(2020, 5, 22),
        minDate: new Date(),
        startingDay: 1
    };
    // Disable weekend selection
    function disabled(data) {
        var date = data.date,
            mode = data.mode;
        var isHoliday = false;
        if(!$scope.holidays){
            return mode === 'day' && (
                date.getDay() === 0 || 
                date.getDay() === 6 || 
                //St silvestre
                (
                    date.getDate() === silvestre.getDate() && 
                    date.getMonth() === silvestre.getMonth()-1
                )
            );
        }else{
            return mode === 'day' && (
                date.getDay() === 0 || 
                date.getDay() === 6 || 
                //St silvestre
                (
                    date.getDate() === silvestre.getDate() && 
                    date.getMonth() === silvestre.getMonth()-1
                ) ||
                isDisabledDate(data)
            );  
        }
        
    }
    var today = new Date();
 //   $scope.holidays = [
 //       new Date(today.getFullYear(),today.getMonth(),5),
 //       new Date(today.getFullYear(),today.getMonth(),6),
 //       new Date(today.getFullYear(),today.getMonth(),7),
 //       new Date(2016, 9, 12),
 //   ];
    $scope.holidays = $scope.properties.holidays;
    $scope.appointments = [
        new Date(today.getFullYear(),today.getMonth(),3),
        new Date(today.getFullYear(),today.getMonth(),7),
        new Date(today.getFullYear(),today.getMonth(),20),
    ];
    function areDatesEqual(date1, date2) {
        return date1.setHours(0,0,0,0) === date2.setHours(0,0,0,0);
    }
    function isDisabledDate(data) {
        var date = data.date,
            mode = data.mode;
        return mode === 'day' && (DateInArray(date,$scope.holidays));
    }
    function DateInArray(date1,arrDate){
        var isHoliday = false;
        for(var i=0;i<arrDate.length;i++){
            var mdate1 = date1.setHours(0,0,0,0);
            var marrDate = arrDate[i].setHours(0,0,0,0)
            if(marrDate == mdate1){
                isHoliday = true;
                return isHoliday;
            }
        }
    }
    $scope.toggleMin = function() {
        $scope.inlineOptions.minDate = $scope.inlineOptions.minDate ? null : new Date();
        $scope.dateOptions.minDate = $scope.inlineOptions.minDate;
    };
    $scope.toggleMin();
    $scope.open1 = function() {
        $scope.popup1.opened = true;
    };
    $scope.setDate = function(year, month, day) {
        $scope.dt = new Date(year, month, day);
    };
    $scope.formats = ['dd/MM/yyyy','dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
    //$scope.format = $scope.formats[0];
    $scope.format = $scope.properties.dateFormat;
    $scope.altInputFormats = ['M!/d!/yyyy'];
    $scope.popup1 = {
        opened: false
    };
    $scope.dayClass = function(date, mode) {
        if (mode === 'day') {
            var dateToCheck = new Date(date);
            for(var i = 0; i < $scope.appointments.length ; i++) {
                if(areDatesEqual($scope.appointments[i], dateToCheck)){
                    return 'appointment';
                }
            }
        }
        
        return '';
    };
    $scope.dateSelected = function(){
        var dateSelected = new Date($scope.dt);
        for(var i = 0; i < $scope.appointments.length ; i++) {
            if(areDatesEqual($scope.appointments[i], dateSelected)){
                performAction();
            }
        }
    };
    function performAction(){
        alert("Appointment date selected");
    }
    
    
    // FIN
},
      template: '<style>\n    .full button span {background-color: limegreen;border-radius: 32px;color: black;}\n    .partially button span {background-color: orange;border-radius: 32px;color: black;}\n</style>\n<div ng-class="{\n    \'form-horizontal\': properties.labelPosition === \'left\' && !properties.labelHidden,\n    \'row\': properties.labelPosition === \'top\' && !properties.labelHidden || properties.labelHidden\n    }">\n    <div class="form-group">\n        <label\n            ng-if="!properties.labelHidden"\n            ng-class="{ \'control-label--required\': properties.required }"\n            class="control-label col-xs-{{ !properties.labelHidden && properties.labelPosition === \'left\' ? properties.labelWidth : 12 }}">\n            {{ properties.label | uiTranslate }}\n        </label>\n\n        <div\n            class="col-xs-{{ 12 - (!properties.labelHidden && properties.labelPosition === \'left\' ? properties.labelWidth : 0) }}">\n            <p class="input-group">\n                 <input class="form-control" ng-model="properties.bt"\n                    name="{{name}}"\n                    type="text"\n                    uib-datepicker-popup="{{format}}" \n                    placeholder="{{ properties.placeholder | uiTranslate }}"\n                    is-open="popup1.opened"\n                    ng-readonly="properties.readOnly"\n                    ng-required="properties.required"\n                    datepicker-options="dateOptions"\n                    data-timezone="UTC"\n                    close-text="Close" \n                    current-text="Aujourd\'hui" \n                    clear-text="Effacer" \n                    alt-input-formats="altInputFormats" />\n                <span class="input-group-btn">\n                    <button type="button" class="btn btn-default" ng-click="open1()" ng-disabled="properties.readOnly">\n                        <i class="glyphicon glyphicon-calendar"></i>\n                    </button>\n                </span>\n            </p>\n            <div ng-messages="$form[name].$dirty && $form[name].$error "\n                 ng-messages-include="forms-generic-errors.html" role="alert"></div>\n        </div>\n    </div>\n</div>'
    };
  });
